/*show hide menu*/

let isOpen = false;

document.getElementById("menu").addEventListener("click", showHide);

let content = document.getElementsByClassName("container-content")[0];


function showHide() {
    
    let sidebarHideShow = document.getElementsByClassName("navStyle")[0];

    if (isOpen) {
        sidebarHideShow.style.display = "none";
        content.style.position = "absolute";
        content.style.left = "300px";
        content.style.width = "calc(100% - 300px)"; 
        isOpen = false;
    }
        else {
            sidebarHideShow.style.display = "block";  
            content.style.position = "absolute";
            content.style.left = "25vw";
            content.style.width = "calc(100% - 25vw)";
            isOpen = true;
        }
}
  
