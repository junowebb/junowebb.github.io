function openAbt(text){
    document.getElementById("abtText").innerText = text;
    document.getElementById("dim").style.display = "block";
    document.getElementById("abtRect").style.display = "block";
}

function closeAbt(){
    document.getElementById("dim").style.display = "none";
    document.getElementById("abtRect").style.display = "none";
}
//i need to code this to where the user can click "X" to exit to abtRect
//i have no idea how to incorporate a clickable "X"
//help me :(

//abtrect milo and abtrect Trico 